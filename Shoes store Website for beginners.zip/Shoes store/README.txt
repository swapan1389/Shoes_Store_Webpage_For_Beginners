XAMPP SERVER VERSION-
Server: 127.0.0.1 via TCP/IP
Server type: MariaDB
Server connection: SSL is not being used Documentation
Server version: 10.4.25-MariaDB - mariadb.org binary distribution
Protocol version: 10
User: root@localhost
Apache/2.4.54 (Win64) OpenSSL/1.1.1p PHP/8.1.10
Database client version: libmysql - mysqlnd 8.1.10
PHP extension: mysqli Documentation curl Documentation mbstring Documentation
PHP version: 8.1.10
phpMyAdmin
Version information: 5.2.0